let movies = [
    {
        name: 'Game of Thrones',
        des: 'The story of Game of Thrones takes place in a fantasy world, upon the continent Westeros, with one storyline occurring on another continent to the east, Essos. The season focuses on the family of Eddard Stark, the Warden of the North.',
        image: 'images/slider 2.PNG'
    },
    {
        name: 'House of dragons',
        des: 'Set centuries before the events of Game of Thrones, House of the Dragon tells the story of House Targaryen, the legendary family who ruled the Seven Kingdoms of Westeros. The series follows the Targaryens journey from their beginnings as the last family of dragonlords to their eventual downfall leading up to the events of, George R.R. Martins book Fire & Blood.',
        image: 'images/slider 1.PNG'
    },
    {
        name: 'Euphoria',
        des: 'Euphoria follows a group of high school students as they navigate love and friendships in a world of drugs, sex, trauma and social media.',
        image: 'images/slider 3.PNG'
    },
    {
        name: 'Shōgun',
        des: 'The miniseries is loosely based on the adventures of English navigator William Adams, who journeyed to Japan in 1600 and rose to high rank in the service of the shōgun.',
        image: 'images/slider 4.PNG'
    },
    {
        name: 'luca',
        des: 'A young boy experiences an unforgettable seaside summer on the Italian Riviera filled with gelato, pasta and endless scooter rides. Luca shares these adventures with his newfound best friend, but all the fun is threatened by a deeply-held secret',
        image: 'images/slider 5.PNG'
    }
]
